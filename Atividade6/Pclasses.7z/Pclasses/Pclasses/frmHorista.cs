﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstHor_Click(object sender, EventArgs e)
        {
            Horista ObjHorista = new Horista();//criação do objeto horista
            ObjHorista.NomeEmpregado = txtNome.Text; //setando o valor para as propriedades do projeto horista
            ObjHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            ObjHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntrada.Text);
            ObjHorista.SalarioHora = Convert.ToDouble(txtSalarioHora.Text);
            ObjHorista.NumeroHora = Convert.ToInt32(txtHorasTrab.Text);
            ObjHorista.DiasFalta = Convert.ToInt32(txtDiasFalta.Text);

            MessageBox.Show("Nome = " + ObjHorista.NomeEmpregado + "\n" + "Matrícula = " + ObjHorista.Matricula + "\n" + "Tempo Trabalho: "
                + ObjHorista.TempoTrabalho() + " dias" + "\n" +"Dias faltados: "+ObjHorista.DiasFalta+"\n"+ "Salário Final: " + ObjHorista.SalarioBruto().ToString("N2"));
        }

        private void btnInstHorParam_Click(object sender, EventArgs e)
        {
                
        }
    }
}
