﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    abstract internal class Empregado //criação da classe Empregado
    {
        //criação de atributos e propriedades
        private int matricula;
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula //propriedade Matricula
        {
            get { return matricula; }//get pega o valor do atributo
            set { matricula = value; }//set seta o valor do atributo
        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        //métodos são ações ou comportamentos
        public virtual int TempoTrabalho()//virtual é uma autorização para que este método seja reescrito quando for herdado
        {
            TimeSpan span =
                DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days);//retorna em dias o tempo do funcionario na empresa
        }
        public abstract double SalarioBruto();//toda vez que o método for abstrato, a classe deve ser abstrata - não é possível criar um objeto de uma classe que é abstrata

        public Empregado()
        {
            System.Windows.Forms.MessageBox.Show("Classe empregado");//inserindo um forms para identificar a classe empregado; é um constructor
        }
        public Empregado(int mat, string nome, DateTime datax)//constructor: criando parâmetros para a classe
        {
            matricula = mat;
            nomeEmpregado = nome;
            dataEntradaEmpresa = datax;
        }
    }
}
