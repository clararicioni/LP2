﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class Mensalista : Empregado //classe mensalista é herança (filha) da classe empregado
    {
        public double SalarioMensal { get; set; }//propriedades
        public override double SalarioBruto()//override = sobrescrever o método
        {
            return SalarioMensal;
        }
        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Classe mensalista");//inserindo um forms para identificar a classe empregado; é um constructor
        }
        public Mensalista(int matx, string nomex, DateTime datax, double salx)//constructor: criando parâmetros para a classe
        {
            this.NomeEmpregado = nomex;//é necessário usar o this por conta da herança Mensalista : Empregado
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }
        public static String Empresa = "Toyota";//variável static: somente visualização
        public const String Filial = "Sorocaba";//variável const: mesma coisa que static
    }
}
