﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int N = 2;
            double[,] matriz = new double[N, 4];
            string saida = "";
            double totalMes, totalGeral=0;

            for(int i = 0; i < N; i++)
            {
                totalMes = 0;
                for(int j = 0; j < 4; j++)
                {
                    string auxiliar = Interaction.InputBox($"Insira o valor do mês {i+1}, Semana {j+1}", "Entrada de dados");
                    if(double.TryParse(auxiliar, out matriz[i, j])){
                        if (matriz[i, j] < 0) {
                            MessageBox.Show("Entre com valores válidos maiores que 0.");
                            j--;
                        }
                        else
                        {
                            saida = $"Total do mês: {i + 1} Semana: {j + 1} {(matriz[i, j].ToString("N2"))}";
                            totalMes += matriz[i, j];
                            lstbxTotal.Items.Add(saida);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Entre com um número valido.");
                        j--;
                    }
                }
                totalGeral += totalMes;
                saida = $"Total Mês: {totalMes.ToString("C2")}";
                lstbxTotal.Items.Add(saida);
                lstbxTotal.Items.Add("-----------------");
            }
            saida = $"Total Geral: {totalGeral.ToString("C2")}";
            lstbxTotal.Items.Add(saida);


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxTotal.Items.Clear();
        }
    }
}
