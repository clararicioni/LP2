﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PInss
{
    public partial class Form1 : Form
    {
        double salariobruto, numfilhos, descontoINSS, descontoIRPF, salfamilia, salliquido;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter inválido!");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAliquotaINSS.Text = "";
            txtAliquotaIRPF.Text = "";
            txtDescINSS.Text = "";
            txtSalFamilia.Text = "";
            txtDescIRPF.Text = "";
            txtSalLiquido.Text = "";
            txtNome.Text = " ";
            mskdbxSalario.Text = "";
            nupFilhos.Value = 0;
            salariobruto = 0; numfilhos = 0; descontoINSS = 0; descontoIRPF = 0; salfamilia = 0; salliquido = 0;
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            //cálculo e alíquota INSS
            double.TryParse(mskdbxSalario.Text, out salariobruto);
            double.TryParse(nupFilhos.Text, out numfilhos);
            if (salariobruto <= 800.47)
            {
                txtAliquotaINSS.Text = "7,65%";
                descontoINSS = (0.0765 * salariobruto);
                txtDescINSS.Text = descontoINSS.ToString();
            } else if (salariobruto <= 1050)
            {
                txtAliquotaINSS.Text = "8.65%";
                descontoINSS = (0.0865 * salariobruto);
                txtDescINSS.Text = descontoINSS.ToString();
            } else if (salariobruto <= 1400.77)
            {
                txtAliquotaINSS.Text = "9.00%";
                descontoINSS = (0.09 * salariobruto);
                txtDescINSS.Text = descontoINSS.ToString();
            } else if (salariobruto <= 2801.56)
            {
                txtAliquotaINSS.Text = "11.00%";
                descontoINSS = (0.11 * salariobruto);
                txtDescINSS.Text = descontoINSS.ToString();
            }
            else
            {
                txtAliquotaINSS.Text = "Teto";
                txtDescINSS.Text = "308.17";
            }
            //cálculo e alíquota IRPF
            if(salariobruto <= 1257.12)
            {
                txtAliquotaIRPF.Text = "Isento";
                descontoIRPF = 0;
                txtDescIRPF.Text = descontoIRPF.ToString();
            }else if(salariobruto <= 2512.08)
            {
                txtAliquotaIRPF.Text = "15,00%";
                descontoIRPF = (0.15 * salariobruto);
                txtDescIRPF.Text = descontoIRPF.ToString();
            }else
            {
                txtAliquotaIRPF.Text = "27.5%";
                descontoIRPF = (0.275 * salariobruto);
                txtDescIRPF.Text = descontoIRPF.ToString();
            }
            //cálculo salário família
            if (salariobruto <= 435.52)
            {
                salfamilia = (22.33 * numfilhos);
                txtSalFamilia.Text = salfamilia.ToString();
            } else if (salariobruto <= 654.61)
            {
                salfamilia = (15.74 * numfilhos);
                txtSalFamilia.Text = salfamilia.ToString();
            }
            else
            {
                salfamilia = 0;
                txtSalFamilia.Text = salfamilia.ToString();
            }
            //cálculo do salário líquido
            salliquido = salariobruto - descontoINSS - descontoIRPF + salfamilia;
            txtSalLiquido.Text = salliquido.ToString();
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if(txtNome.Text == "")
            {
                MessageBox.Show("O nome não pode ficar vazio.");
                txtNome.Focus();
            }else
            if(txtNome.Text.Length > 50)
            {
                MessageBox.Show("Limite de caracteres excedido.");
                txtNome.Text = "";
                txtNome.Focus();
            }
        }
    }
}
