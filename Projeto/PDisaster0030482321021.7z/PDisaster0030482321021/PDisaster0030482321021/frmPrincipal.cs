﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PDisaster0030482321021
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {   //a conexão vai depender da máquina local
                conexao = new SqlConnection("Data Source=apolo;Initial Catalog=LP2;" +
                    "User ID=BD2321021;Encrypt=False;Password=Minecraft2020!");
                conexao.Open();
            }
            catch (SqlException ex) //tratamento de erros caso a conexão dê errado
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex) //tratamento de erros caso não seja um erro do sql
            {
                MessageBox.Show("Outros erros =/"+ex.Message);
            }
        }

        private void cadastroTiposDeEventosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<frmTipo>().Count() > 0)
            {
                Application.OpenForms["frmTipo"].BringToFront();
            }
            else
            {
                frmTipo objFrm2 = new frmTipo();
                objFrm2.MdiParent = this;
                objFrm2.WindowState = FormWindowState.Maximized;
                objFrm2.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
